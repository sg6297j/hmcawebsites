# HMCA 2027 Mentorship · Model Congress Club

The full website, version 3 (graph-paper design): the mentorship tracker (dark by default with a light mode, sign-in page, mentor desk, calendar) plus the email service for welcome emails and sign-in links.

## What's in here

| File | What it is |
| --- | --- |
| `index.html` | The whole site (from the "HMCA Mentorship v3" page) |
| `support.js`, `vendor/` | The page runtime and React, bundled so the site needs no CDN |
| `_ds/` | Base design-system styles (v3 overrides them with its own palette and type) |
| `api/send-email.js`, `lib/templates.js` | Email service (Vercel function) and the two email designs |
| `firestore.rules` | Database rules to paste into Firebase |
| `vercel.json`, `package.json` | Vercel settings and the email service's dependencies |
| `EMAIL-SETUP.md` | Step-by-step email setup, testing and go-live |

## Try it on your computer

Open a terminal in this folder and run `python3 -m http.server 8000`, then visit http://localhost:8000. (Opening `index.html` by double-clicking won't sign in, because Firebase needs a real web address.)

## Put it online (Vercel)

1. Go to vercel.com → Add New → Project, and upload this folder (or push it to GitHub and import it). No build settings needed.
2. In Firebase → Authentication → Settings → Authorized domains, add your new Vercel address so sign-in works there.
3. Follow `EMAIL-SETUP.md` to switch on the emails. Until then the site works normally, it just doesn't send emails.

The site also runs on any static host (Netlify, GitHub Pages). Only the email service needs Vercel.
