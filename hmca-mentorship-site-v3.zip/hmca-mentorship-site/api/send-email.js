// POST /api/send-email  (Vercel serverless function)
//
//   { "type": "welcome" }                 + header  Authorization: Bearer <Firebase ID token>
//       Sends the welcome email to the signed-in user. Once per account, ever.
//   { "type": "magic", "email": "..." }
//       Sends a one-time sign-in link, only to emails that already have an account.
//       Repeat requests within 60 seconds are ignored, so a double tap never sends twice.
//
// GET /api/send-email?test=<MAIL_TEST_KEY>
//       Sends both emails to the lead mentor (sg6297j@gmail.com) so you can check them in a real inbox.
//
// Environment variables (Vercel → Project → Settings → Environment Variables):
//   FIREBASE_SERVICE_ACCOUNT  the whole service-account JSON (Firebase → Project settings → Service accounts → Generate new private key)
//   GMAIL_USER                the Gmail address that sends the emails, e.g. sg6297j@gmail.com
//   GMAIL_APP_PASSWORD        a 16-character Google app password for that account
//   SITE_URL                  the live site, e.g. https://hmca-mentorship.vercel.app
//   MAIL_TEST_KEY             any long random string, used only by the test URL above
//   MAIL_MODE                 leave unset while testing. Set to "live" to email everyone.

import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';
import nodemailer from 'nodemailer';
import crypto from 'node:crypto';
import { welcomeEmail, magicLinkEmail, firstNameOf } from '../lib/templates.js';

const ADMIN_EMAIL = 'sg6297j@gmail.com';
const LIVE = process.env.MAIL_MODE === 'live';
const SITE_URL = String(process.env.SITE_URL || '').replace(/\/+$/, '');
const MAGIC_COOLDOWN_MS = 60 * 1000;
const STALE_CLAIM_MS = 5 * 60 * 1000;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const httpErr = (status, message) => Object.assign(new Error(message), { status, publicMessage: message });

function firebase() {
  if (!getApps().length) {
    if (!process.env.FIREBASE_SERVICE_ACCOUNT) throw httpErr(500, 'FIREBASE_SERVICE_ACCOUNT is not set.');
    initializeApp({ credential: cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT)) });
  }
  return { auth: getAuth(), db: getFirestore() };
}

let transport;
function mailer() {
  if (!process.env.GMAIL_USER || !process.env.GMAIL_APP_PASSWORD) throw httpErr(500, 'GMAIL_USER / GMAIL_APP_PASSWORD are not set.');
  transport ||= nodemailer.createTransport({
    host: 'smtp.gmail.com', port: 465, secure: true,
    auth: { user: process.env.GMAIL_USER, pass: String(process.env.GMAIL_APP_PASSWORD).replace(/\s+/g, '') },
  });
  return transport;
}

// Test mode (MAIL_MODE not "live"): only the lead mentor's inbox gets mail, including
// plus-addresses like sg6297j+mentee1@gmail.com, so you can sign up test accounts safely.
function allowedRecipient(email) {
  if (LIVE) return true;
  const [local = '', domain = ''] = email.toLowerCase().split('@');
  const [aLocal, aDomain] = ADMIN_EMAIL.split('@');
  return domain === aDomain && local.split('+')[0].replace(/\./g, '') === aLocal.replace(/\./g, '');
}

// Duplicate guard. Every email has a record in Firestore (collection "mail"). A Firestore
// transaction "claims" the record before sending, so two requests at the same moment can
// never both send. canSendAgain decides whether an existing record may be reused.
async function claim(db, ref, canSendAgain) {
  return db.runTransaction(async tx => {
    const snap = await tx.get(ref);
    const now = Date.now();
    if (snap.exists && !canSendAgain(snap.data(), now)) return false;
    tx.set(ref, { status: 'sending', claimedAt: now }, { merge: true });
    return true;
  });
}

async function deliver(ref, to, msg) {
  try {
    const info = await mailer().sendMail({
      from: `"Model Congress Club" <${process.env.GMAIL_USER}>`,
      replyTo: ADMIN_EMAIL,
      to,
      subject: (LIVE ? '' : '[Test] ') + msg.subject,
      html: msg.html,
      text: msg.text,
    });
    if (ref) await ref.set({ status: 'sent', sentAt: Date.now(), to, messageId: info.messageId || '' }, { merge: true });
    return true;
  } catch (e) {
    if (ref) await ref.set({ status: 'failed', failedAt: Date.now(), error: String(e && e.message || e).slice(0, 300) }, { merge: true });
    throw e;
  }
}

const signInUrl = () => SITE_URL + '/?signin';
const linkSettings = () => ({ url: SITE_URL + '/?signin=link', handleCodeInApp: true });

async function sendWelcome(req) {
  const { auth, db } = firebase();
  const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (!token) throw httpErr(401, 'Sign in first.');
  let user;
  try { user = await auth.verifyIdToken(token); } catch (e) { throw httpErr(401, 'Your sign-in expired. Sign in again.'); }
  const email = String(user.email || '').toLowerCase();
  if (!email) throw httpErr(400, 'This account has no email address.');
  const profile = (await db.doc(`users/${user.uid}`).get()).data();
  if (!profile) throw httpErr(409, 'Account not saved yet.');

  const ref = db.doc(`mail/welcome_${user.uid}`);
  // Never resend once sent. Retry only if the last attempt failed or got stuck.
  const ok = await claim(db, ref, (d, now) => d.status === 'failed' || (d.status === 'sending' && now - (d.claimedAt || 0) > STALE_CLAIM_MS));
  if (!ok) return { ok: true, sent: false, reason: 'already-sent' };
  if (!allowedRecipient(email)) {
    await ref.set({ status: 'skipped-test-mode', to: email, at: Date.now() }, { merge: true });
    return { ok: true, sent: false, reason: 'test-mode' };
  }
  const msg = welcomeEmail({ firstName: profile.name, role: profile.role, status: profile.status, lead: !!profile.lead, signInUrl: signInUrl() });
  await deliver(ref, email, msg);
  return { ok: true, sent: true };
}

async function sendMagic(rawEmail) {
  const { auth, db } = firebase();
  const email = String(rawEmail || '').trim().toLowerCase();
  if (!EMAIL_RE.test(email)) throw httpErr(400, 'Enter a valid email address.');
  // Same answer whether or not the account exists, so nobody can probe for accounts.
  const reply = { ok: true };

  let user;
  try { user = await auth.getUserByEmail(email); } catch (e) { return reply; }

  const ref = db.doc(`mail/magic_${crypto.createHash('sha256').update(email).digest('hex').slice(0, 32)}`);
  const ok = await claim(db, ref, (d, now) =>
    (d.status !== 'sending' || now - (d.claimedAt || 0) > STALE_CLAIM_MS) && now - (d.sentAt || 0) >= MAGIC_COOLDOWN_MS);
  if (!ok) return reply;
  if (!allowedRecipient(email)) {
    await ref.set({ status: 'skipped-test-mode', at: Date.now() }, { merge: true });
    return reply;
  }
  const profile = (await db.doc(`users/${user.uid}`).get()).data() || {};
  const link = await auth.generateSignInWithEmailLink(email, linkSettings());
  const msg = magicLinkEmail({
    firstName: profile.name || String(user.displayName || '').split('|')[0],
    role: profile.role, status: profile.status, lead: !!profile.lead, link,
  });
  await deliver(ref, email, msg);
  return reply;
}

async function sendTest(key) {
  if (!process.env.MAIL_TEST_KEY || key !== process.env.MAIL_TEST_KEY) throw httpErr(403, 'Wrong test key.');
  const { auth, db } = firebase();
  let profile = { name: 'Clay', role: 'mentee', status: 'pending', lead: false };
  let link = signInUrl();
  try {
    const admin = await auth.getUserByEmail(ADMIN_EMAIL);
    const p = (await db.doc(`users/${admin.uid}`).get()).data();
    if (p) profile = p;
    link = await auth.generateSignInWithEmailLink(ADMIN_EMAIL, linkSettings());
  } catch (e) { console.warn('test: using sample data', e && e.code); }
  const name = firstNameOf(profile.name) || 'Clay';
  await deliver(null, ADMIN_EMAIL, welcomeEmail({ firstName: name, role: profile.role, status: profile.status, lead: !!profile.lead, signInUrl: signInUrl() }));
  await deliver(null, ADMIN_EMAIL, magicLinkEmail({ firstName: name, role: profile.role, status: profile.status, lead: !!profile.lead, link }));
  return { ok: true, sent: 2, to: ADMIN_EMAIL, mode: LIVE ? 'live' : 'test' };
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (!SITE_URL) throw httpErr(500, 'SITE_URL is not set.');
    if (req.method === 'GET' && req.query && req.query.test) return res.status(200).json(await sendTest(String(req.query.test)));
    if (req.method !== 'POST') return res.status(405).json({ error: 'Use POST.' });
    let body = req.body || {};
    if (typeof body === 'string') { try { body = JSON.parse(body || '{}'); } catch (e) { throw httpErr(400, 'Bad request.'); } }
    if (body.type === 'welcome') return res.status(200).json(await sendWelcome(req));
    if (body.type === 'magic') return res.status(200).json(await sendMagic(body.email));
    throw httpErr(400, 'Unknown email type.');
  } catch (e) {
    console.error('send-email', e);
    return res.status(e.status || 500).json({ error: e.publicMessage || 'The email could not be sent. Try again in a minute.' });
  }
}
