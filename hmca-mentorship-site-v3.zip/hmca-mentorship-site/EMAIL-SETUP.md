# HMCA emails: setup and go-live

Two emails, sent from your Gmail as "Model Congress Club", with replies going to sg6297j@gmail.com:

- **Welcome**: sent once, right after someone creates an account (email/password or Google).
- **Sign-in link**: sent when someone taps "Email me a sign-in link instead" on the sign-in page.

How duplicates are blocked: every email gets a record in Firestore (`mail` collection). The server claims that record inside a transaction before sending, so a welcome email can only ever go out once per account, and a sign-in link can't be sent again to the same address within 60 seconds (double taps, refreshes). Sign-in links only go to emails that already have an account.

Files: `api/send-email.js` (the server function), `lib/templates.js` (the two emails), `firestore.rules`, `vercel.json`, `package.json`.

## 1. Gmail app password (5 min)

1. Google Account → Security → turn on 2-Step Verification if it isn't already.
2. Search "App passwords", create one called `HMCA site`, copy the 16 characters.

## 2. Firebase (5 min)

1. Authentication → Sign-in method → Email/Password → turn on **Email link (passwordless sign-in)** → Save.
2. Authentication → Settings → Authorized domains → add your Vercel domain (e.g. `hmca-mentorship.vercel.app`).
3. Firestore Database → Rules → paste `firestore.rules` → Publish.
4. Project settings → Service accounts → **Generate new private key**. Keep that JSON file private.

## 3. Vercel

1. Export the **HMCA Mentorship Final** page as HTML and save it as `index.html` in this folder (the copy here is older).
2. Import this folder as a Vercel project and add these environment variables:

| Name | Value |
| --- | --- |
| `FIREBASE_SERVICE_ACCOUNT` | the whole JSON file from step 2.4, pasted as one value |
| `GMAIL_USER` | sg6297j@gmail.com |
| `GMAIL_APP_PASSWORD` | the 16 characters from step 1 |
| `SITE_URL` | your site, e.g. https://hmca-mentorship.vercel.app |
| `MAIL_TEST_KEY` | any long random string |

Leave `MAIL_MODE` unset for now. That's **test mode**: emails only go to sg6297j@gmail.com and plus-addresses like sg6297j+mentee1@gmail.com, and subjects start with `[Test]`.

3. In the page code, set `const MAIL_API = 'https://your-site.vercel.app';` (near the top of the script), re-export, redeploy.

## 4. Test

1. Open `https://your-site.vercel.app/api/send-email?test=YOUR_MAIL_TEST_KEY`. Both emails land in sg6297j@gmail.com.
2. Create an account with `sg6297j+test1@gmail.com`. One welcome email arrives. Log out and back in: no second one.
3. On the sign-in page, type that email and tap "Email me a sign-in link instead" twice fast. One email arrives. Open the link on the same browser and you're signed in.

## 5. Go live

Add `MAIL_MODE` = `live` in Vercel and redeploy. Every new account now gets the welcome email, and anyone with an account can request a sign-in link. Gmail allows about 500 emails a day, which is plenty for the delegation.
